a = 5 #Adalah Assignment
print("Nilai A = ",a)
a += 1 #Artinya adalah a = a + 1
print("Nilai A += 1, nilai a menjadi",a)
a -= 2 #Artinya adalah a = a - 2
print("Nilai A -= 2, nilai a menjadi",a)
a *= 5 #Artinya adalah a = a x 5
print("Nilai A x= 5, nilai a menjadi",a)
a /= 2 #Artinya adalah a = a : 5
print("Nilai A := 2, nilai a menjadi",a)
print("\n")
b = 10 #Adalah Assignment
print("Nilai B = ",b)
b %= 3 #Artinya adalah b = b %= 3
print("Nilai B %= 3, nilai b menjadi",b)
b = 10 #Adalah Assignment
print("Nilai B = ",b)
b //= 3 #Artinya adalah b = b //= 3
print("Nilai B //= 3, nilai b menjadi",b)
print("\n")
c = 5 #Adalah Assignment
print("Nilai c = ",c)
c **= 3 #Artinya adalah c = c **= 3
print("Nilai c **= 3, nilai b menjadi",c)