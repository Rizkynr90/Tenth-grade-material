#Assignment Nilai
a = 10
x = 20
lebar = 2000
total = (a*x)+lebar

#Pemanggilan Pertama
print("Nilai a = ", a)
print("Nilai x = ", x)
print("Lebar = ", lebar)
print("Total = ", total)

#Penamaan
nilai_y = 15
juta10 = 1000000
nilaiZ = 17.5

#Pemanggilan Kedua
print("Nilai a = ", a)
a = 30
print("Nilai a = ", a)

#Assignment Indirect
b = a
print("Nilai b = ",a)