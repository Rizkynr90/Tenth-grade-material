print("PROGRAM KONVERSI TEMPERATUR")

#Celcius
celcius = float(input("Masukan angka = "))
print("Suhu adalah = ", celcius, "Celcius")

#Reamur
reamur = (4/5)*celcius
print("Suhu dalam reamur adalah = ", reamur, " Reamur")

#Fahrenheit 
fahren = ((9/5)*celcius) + 32
print("Suhu dalam Fahrenheit = ", fahren, " Fahrenheit")

#Kelvin
kelvin = celcius + 273
print("Suhu dalam kelvin = ", kelvin, " Kelvin")