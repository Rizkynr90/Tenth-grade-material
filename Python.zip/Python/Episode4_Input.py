#Data yang dimasukan pasti String
data = input("Masukan data = ")
print("Data = ", data, " type = ", type(data))

#Data Integer
data_int = int(input("Masukan angka = "))
print("Data = ", data_int, " type = ", type(data_int))

#Data float
data_float = float(input("Masukan Angka = "))
print("Data = ", data_float, " type = ", type(data_float))

#Data Boolean
data_bool = bool(int(input("Masukan angka biner = ")))
print("Data = ", data_bool, "type = ", type(data_bool))